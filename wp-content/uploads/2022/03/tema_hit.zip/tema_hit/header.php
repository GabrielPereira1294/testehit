<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <title>Theme Wordpress</title>
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/style.css" rel="stylesheet">
    <?php wp_head(); ?>
</head>

<body class="py-5">

    <main>
        <div class="container text-center">
            <div class="d-flex justify-content-center">
                <img src="<?php echo get_template_directory_uri(); ?>/img/logo-hit-branco.svg" width="160" class="py-5">

            </div>
            <p>
                <?php
                wp_nav_menu([
                    'menu'            => 'Primary',
                    'theme_location'  => '',
                    'container'       => 'li',
                    // 'container_id'    => 'navbarCollapse',
                    'container_class' => 'hs-menu-item hs-menu-depth-1',
                    // 'menu_id'         => false,
                    'menu_class'      => 'hs-menu-item',
                    'items_wrap'      => '<li class="hs-menu-item hs-menu-depth-1 %2$s" id="%1$s">%3$s</li>',
                    //'after'           => '<div class="child-trigger"><i></i></div>',
                    'depth'           => 0,
                    // 'fallback_cb'     => 'bs4navwalker::fallback',
                    // 'walker'          => new bs4navwalker()
                ]);
                ?>
                <a href="#" class="btn btn-primary my-2">INTRODUÇÃO</a>
                <a href="#" class="btn btn-primary my-2">CONTATO</a>
            </p>
            <div style="display: inline-block;">
                <h4>Introdução</h4>
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-line divider-custom-line-icon"></div>
                    <div class="divider-custom-line"></div>
                </div>
            </div>