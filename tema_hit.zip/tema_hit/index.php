<?php get_header(); ?>
<div class="h-100 p-5 text-white bg-primary rounded-3">
    <?php the_content(); ?>
</div>
<?php get_footer(); ?>