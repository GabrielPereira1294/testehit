</div>
</main>
<?php wp_footer() ?>
</body>
<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>

</html>